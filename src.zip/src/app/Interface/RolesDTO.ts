export interface RoleDto {
    id?: number;
    name?: string;
    checked?: boolean;
}