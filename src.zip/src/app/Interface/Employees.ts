export interface Employees {
    userId: number[],
    profileId: number
}