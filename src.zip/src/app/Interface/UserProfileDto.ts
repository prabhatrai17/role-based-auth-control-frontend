export interface UserProfileDto {
    userIds: number[],
    profileId: number
}