export interface ProfileViewModel {
    profileId?: number,
    profileDescription: string,
    profileName: string,
    roleIds: number[]
}