export interface Role{
    roleId?:number;
    roleName: string;
    roleDescription: string;

}