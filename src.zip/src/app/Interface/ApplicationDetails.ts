export interface ApplicationDetails{
    applicationId?:number,
    applicationName:string,
    applicationDescription:string,
    applicationURL:string
}